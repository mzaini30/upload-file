<?php 
include 'base.php';
include 'auth.php';
include 'view/beranda.php';	