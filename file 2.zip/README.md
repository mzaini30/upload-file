# Variabel yang harus disetting

- pug/beranda.coffee