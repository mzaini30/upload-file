cd pug
pug . -w -o ../view -E php 